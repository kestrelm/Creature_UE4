#include "CustomProceduralMesh.h"
#include "CreaturePlugin.h"

void CreaturePlugin::StartupModule()
{
}

void CreaturePlugin::ShutdownModule()
{
}

IMPLEMENT_MODULE(CreaturePlugin, CreaturePlugin)